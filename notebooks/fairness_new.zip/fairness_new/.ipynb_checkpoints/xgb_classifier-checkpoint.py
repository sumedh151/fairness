import numpy as np
import xgboost as xgb

def train_xgb_classifier(X, y):
    """
    Train an XGBoost classification model.

    This function checks the format of the target variable `y`, converts 
    one-hot encoded labels to integer labels if necessary, and determines 
    whether the classification task is binary or multiclass. It then 
    fits an XGBoost classifier to the provided feature set `X` and 
    target labels `y`.

    Parameters:
    X : array-like, shape (n_samples, n_features)
        Feature matrix for the classification task.

    y : array-like, shape (n_samples,) or shape (n_samples, n_classes)
        Target labels for the classification task. Can be either
        integer labels for binary/multiclass classification or one-hot
        encoded labels.

    Returns:
    model : XGBClassifier
        The trained XGBoost classification model.
    
    Examples:
    >>> X = [[1, 2], [3, 4], [5, 6]]
    >>> y = [0, 1, 0]  # Binary labels
    >>> model = train_xgb_classifier(X, y)

    >>> y_one_hot = [[1, 0], [0, 1], [1, 0]]  # One-hot encoded labels
    >>> model = train_xgb_classifier(X, y_one_hot)
    """
    
    # Check if y is one-hot encoded
    if y.ndim > 1 and y.shape[1] > 1:
        print("Converting one-hot encoded labels to integers.")
        y = np.argmax(y, axis=1)

    if len(np.unique(y)) == 2:
        print("Binary classification")
        model_type = 'binary'
    else:
        print("Multiclass classification")
        model_type = 'multiclass'
    
    model = xgb.XGBClassifier(use_label_encoder=False, eval_metric='mlogloss' if model_type == 'multiclass' else 'logloss')    
    model.fit(X, y)
    
    return model
