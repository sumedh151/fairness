import torch
import torch.nn as nn

class Encoder(nn.Module):
    def __init__(self, input_dim, output_dim):
        super(Encoder, self).__init__()
        self.fc1 = nn.Linear(input_dim, output_dim)
        self.relu = nn.ReLU()
    def forward(self, x):
        return self.fc1(x)
    

class Predictor(nn.Module):
    def __init__(self, input_dim, output_dim):
        super(Predictor, self).__init__()
        self.fc1 = nn.Linear(input_dim, output_dim)
        self.output_dim = output_dim
    def forward(self, x):
        x = self.fc1(x)
        if self.output_dim == 1:
            return torch.sigmoid(x)
        return x
    
    
class Adversary(nn.Module):
    def __init__(self, input_dim, output_dim):
        super(Adversary, self).__init__()
        self.fc1 = nn.Linear(input_dim, output_dim)
        self.output_dim = output_dim
    def forward(self, x):
        x = self.fc1(x)
        if self.output_dim == 1:
            return torch.sigmoid(x)
        return x
