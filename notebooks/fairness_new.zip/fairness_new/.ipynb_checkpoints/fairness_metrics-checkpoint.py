import pandas as pd

def get_demographic_parity(y_true, y_pred, data, sensitive_vars):
    """
    Calculate demographic parity for different sensitive groups based on predictions.

    Args:
    - y_true (numpy array): True labels.
    - y_pred (numpy array): Binary predictions.
    - data (pandas DataFrame): DataFrame containing sensitive attributes.
    - sensitive_vars (int): A dictionary with sensitive columns as keys.

    Returns:
    - all_group_stats (dict): Dictionary with group statistics for each sensitive attribute.
    - all_demographic_parity (dict): Dictionary with demographic parity for each sensitive attribute.
    """
    df = pd.DataFrame({
        'y_true': y_true,
        'y_pred': y_pred
    }, index=data.index)

    sensitive_cols = list(sensitive_vars.keys())
    
    for sc in sensitive_cols:
        df[sc] = data[sc]
    
    all_group_stats = {}
    all_demographic_parity = {}

    for sensitive_col in sensitive_cols:
        group_stats = df.groupby(sensitive_col).agg(
            total_predictions=('y_pred', 'size'),
            positive_predictions=('y_pred', 'sum')
        )
        group_stats['positive_prediction_rate'] = group_stats['positive_predictions'] / group_stats['total_predictions']
        demographic_parity = group_stats['positive_prediction_rate'].max() - group_stats['positive_prediction_rate'].min()

        all_group_stats[sensitive_col] = group_stats
        all_demographic_parity[sensitive_col] = demographic_parity

    return all_group_stats, all_demographic_parity