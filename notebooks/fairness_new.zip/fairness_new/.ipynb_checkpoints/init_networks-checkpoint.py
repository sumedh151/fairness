from torch import nn

def initialize_networks(encoder_class, predictor_class, adversary_class, non_sensitive_vars, sensitive_vars, target_vars):
    """
    Initialize the Encoder, Predictor, and Adversaries for the model using specified classes.

    Args:
    - encoder_class (type): The class for the Encoder network.
    - predictor_class (type): The class for the Predictor network.
    - adversary_class (type): The class for the Adversary network.
    - num_non_sensitive (int): Number of non-sensitive features.
    - num_sensitive (int): Number of sensitive features.

    Returns:
    - encoder (nn.Module): Initialized Encoder network.
    - predictors (nn.ModuleList): Module list of initialized Predictor network.
    - adversaries (nn.ModuleList): Module list of initialized Adversary networks.
    """
    
    num_non_sensitive = len(sensitive_vars)
    num_sensitive = len(non_sensitive_vars)
    encoder = encoder_class(input_dim=num_non_sensitive + num_sensitive, output_dim=num_non_sensitive)
    predictors = nn.ModuleList([predictor_class(input_dim=num_non_sensitive, output_dim=i[1]) for i in target_vars.items()])
    adversaries = nn.ModuleList([adversary_class(input_dim=num_non_sensitive, output_dim=i[1]) for i in sensitive_vars.items()])
    return encoder, predictors, adversaries