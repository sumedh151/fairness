import pandas as pd
from sklearn.model_selection import train_test_split

def perform_train_test_split(data, test_size=0.2, val_size=None, random_state=None):
    """
    Splits the dataset into training, validation (optional), and testing sets.

    Parameters:
    - data (pd.DataFrame): The DataFrame containing the dataset with features and target variable.
    - test_size (float): The proportion of the dataset to include in the test split (default is 0.2).
    - val_size (float or None): The proportion of the training data to include in the validation split. If None, no validation split is performed.
    - random_state (int): Seed for the random number generator to ensure reproducibility (default is None).

    Returns:
    - data_train (pd.DataFrame): Training set containing both features and target.
    - data_val (pd.DataFrame or None): Validation set containing both features and target, or None if no validation split is performed.
    - data_test (pd.DataFrame): Testing set containing both features and target.

    Notes:
    - The function splits the data into training and testing sets, and further splits the training 
      set into training and validation sets if `val_size` is provided.

Example:
    >>> data = pd.DataFrame({
    ...     'X1': [0.807, -0.156, 0.482, 0.402, 0.970],
    ...     'X2': [0.550, -0.216, 0.105, -0.294, 0.453],
    ...     'X3': [0.144, -0.027, 0.047, 0.131, 0.358],
    ...     'X4': [0.449, 0.289, 0.391, 0.381, 0.316],
    ...     'S1': [1, 1, 1, 1, 1],
    ...     'Y': [1, 0, 1, 1, 1]
    ... })
    >>> data_train, data_val, data_test = perform_train_test_split(data, val_size=0.1)
    >>> print(data_train.shape, data_val.shape, data_test.shape)
    """
    
    data_train_val, data_test = train_test_split(data, test_size=test_size, random_state=random_state)
    if val_size is not None:
        data_train, data_val = train_test_split(data_train_val, test_size=val_size/(1 - test_size), random_state=random_state)
        return data_train, data_val, data_test
    return data_train_val, data_test