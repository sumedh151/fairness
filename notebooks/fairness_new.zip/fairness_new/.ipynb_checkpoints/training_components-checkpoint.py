import torch.optim as optim
import torch.nn as nn

def initialize_training_components(encoder, predictors, adversaries, target_vars, sensitive_vars, learning_rate=0.01):
    """
    Initializes training components for a model, including loss functions and optimizers.

    Parameters:
    - encoder: The encoder model.
    - predictors: List of predictor models.
    - adversaries: List of adversary models.
    - target_vars: Dictionary of target variables where values dictate loss function choice.
    - sensitive_vars: Dictionary of sensitive variables where values dictate loss function choice.
    - learning_rate (float, optional): Learning rate for optimizers. Default is 0.01.

    Returns:
    - criterion_enc: Loss function for the encoder (MSE).
    - criterion_pred: List of loss functions for predictors (BCELoss or CrossEntropyLoss).
    - criterion_adv: List of loss functions for adversaries (BCELoss or CrossEntropyLoss).
    - optimizer_enc: Optimizer for the encoder (Adam).
    - optimizer_pred: List of optimizers for predictors (Adam).
    - optimizer_adv: List of optimizers for adversaries (Adam).
    
    """

    criterion_enc = nn.MSELoss()
    criterion_pred = [nn.BCELoss() if value == 2 else nn.CrossEntropyLoss() for value in target_vars.values()]
    criterion_adv = [nn.BCELoss() if value == 2 else nn.CrossEntropyLoss() for value in sensitive_vars.values()]

    optimizer_enc = optim.Adam(encoder.parameters(), lr=learning_rate)
    optimizer_pred = [optim.Adam(predictors[i].parameters(), lr=learning_rate) for i in range(len(predictors))]
    optimizer_adv = [optim.Adam(adversaries[i].parameters(), lr=learning_rate) for i in range(len(adversaries))]
    
    return criterion_enc, criterion_pred, criterion_adv, optimizer_enc, optimizer_pred, optimizer_adv
