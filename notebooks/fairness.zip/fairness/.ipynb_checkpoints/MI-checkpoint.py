import pandas as pd
import numpy as np
from sklearn.feature_selection import mutual_info_classif

import seaborn as sns
import scipy
import scipy.cluster.hierarchy as sch
import matplotlib.pyplot as plt


def calculate_MI(dat, 
                 label: str,
                 n: int, 
                 bin_dict: dict = {}):
    """ This functions returns the MI of the top n features with respect to the label variable
    as well as the pairwise MI heatmap between these top n features.

    Parameters
    ----------
    dat : pd.DataFrame
        The data object containg the features and label. All features should be discrete or binning functions
        should be provided via the <bin_dict> argument for the continuous features.
    label : str
        Column name representing label, generally impact of full uw finding vs accelerated uw (0 or 1)
    n : int
        Number of top features by MI with respect to the label variable to be returned
    bin_dict : dict, optional
        Dictionnary to bin the continuous features into discrete features. The structure should be 
        keys representing <column_names> to be binned and the values representing 
        <function_names> used for binning, by default {}

    Returns
    -------
    pd.DataFrame
        Top n features and their MI with respect to the target variable.
        
    Examples
    --------
    >>> from lightspeedcore.utilities import make_fake_data
    >>> from lightspeedcore.eda import calculate_MI
    >>> fake_data = make_fake_data().to_pandas()
    Creating Fake Data
    NOTE: Reference Class is `Female PrefNonSmoker by Age`
    >>> fake_data_to_use = fake_data[['IssueAge', 'IssueYear', 'Duration', 'FaceAmount', 'AttainedAge', 'CalendarYear', 'Deaths']].copy()
    >>> def face_amount_bin(amount):
    ...     if amount < 100000:
    ...             return 1
    ...     elif amount < 300000:
    ...             return 2
    ...     else:
    ...             return 3
    >>> #calculate_MI(dat=fake_data_to_use, label='Deaths', n=4)
    >>> #calculate_MI(dat=fake_data_to_use, label='Deaths', n=4, bin_dict={'FaceAmount': face_amount_bin})
    """
    if bin_dict:
        for var in bin_dict:
            dat[var] = dat[var].apply(bin_dict[var])
    
    mi = mutual_info_classif(dat.drop(label, axis=1).fillna(-1).values, 
                             dat[label],
                             random_state=4, 
                             discrete_features=[True] * dat.drop(label, axis=1).shape[1])
    
    mi_label = pd.DataFrame({'feature': dat.drop(label, axis=1).columns, 'mi': mi})
    
    top_n_features_mi = mi_label.sort_values(by='mi', ascending=False).iloc[:n]['feature'].to_list()
    
    MI_mat = np.zeros((n, n))
    for row, f in enumerate(top_n_features_mi):
        MI_mat[row] = mutual_info_classif(dat[top_n_features_mi].fillna(-1).values, 
                                          dat[f], 
                                          random_state=4, 
                                          discrete_features=[True] * n)

    MI_mat = MI_mat / MI_mat.max(axis=1)[None,:]

    mi_pair = pd.DataFrame(MI_mat, index=top_n_features_mi, columns=top_n_features_mi)
    
    X = mi_pair.corr().values
    d = sch.distance.pdist(X, metric='euclidean') # vector of ('55' choose 2) pairwise distances
    L = sch.linkage(d, method='average', metric='euclidean')
    ind = sch.fcluster(L, 0.5*d.max(), 'distance', depth=2)
    
    new_columns = [mi_pair.columns.tolist()[i] for i in list((np.argsort(ind)))]
    mi_pair_ord = mi_pair.reindex(new_columns, axis=1)
    mi_pair_ord = mi_pair_ord.reindex(new_columns, axis=0)
    
    fig, ax = plt.subplots(figsize=(15,10)) # Sample figsize in inches
    sns.heatmap(mi_pair_ord, annot=True, fmt='.1f', ax=ax)
    
    return mi_label.sort_values(by='mi', ascending=False).iloc[:n]

