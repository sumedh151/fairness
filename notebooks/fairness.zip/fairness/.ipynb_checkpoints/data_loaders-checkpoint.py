import torch
import random
import numpy as np
from torch.utils.data import Dataset, DataLoader

class CustomDataset(Dataset):
    def __init__(self, dataframe):
        self.X = torch.tensor(dataframe.drop(columns=['Y']).values, dtype=torch.float32)
        self.Y = torch.tensor(dataframe[['Y']].values, dtype=torch.float32)

    def __len__(self):
        return len(self.X)

    def __getitem__(self, idx):
        return self.X[idx], self.Y[idx]

def set_seed(seed):
    """
    Set the random seed for reproducibility.
    Args:
    - seed (int): The seed value.
    """
    torch.manual_seed(seed)
    np.random.seed(seed)
    random.seed(seed)
    torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False

def worker_init_fn(worker_id):
    """
    Initialize worker for DataLoader to ensure each worker gets a different seed.
    Args:
    - worker_id (int): The ID of the worker.
    """
    seed = torch.initial_seed() % 2**32  # Get a seed based on the current process seed
    np.random.seed(seed)
    random.seed(seed)

def create_dataloaders(train_df, test_df, val_df=None, batch_size=256, shuffle_train=True, seed=None):
    """
    Create DataLoader instances for training and testing datasets with optional seed setting.

    Args:
    - train_df (pandas DataFrame): DataFrame containing training data. Should be compatible with the CustomDataset.
    - test_df (pandas DataFrame): DataFrame containing testing data. Should be compatible with the CustomDataset.
    - val_df (pandas DataFrame, optional): DataFrame containing validation data. Default is None.
    - batch_size (int, optional): The number of samples per batch. Default is 256.
    - shuffle_train (bool, optional): Whether to shuffle the training data. Default is True.
    - seed (int, optional): The random seed for reproducibility. Default is None.

    Returns:
    - train_loader (torch.utils.data.DataLoader): DataLoader for the training dataset.
    - test_loader (torch.utils.data.DataLoader): DataLoader for the testing dataset.
    - val_loader (torch.utils.data.DataLoader, optional): DataLoader for the validation dataset (if provided).
    """
    if seed is not None:
        set_seed(seed)  # Set seed for reproducibility

    train_dataset = CustomDataset(train_df)
    test_dataset = CustomDataset(test_df)

    train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=shuffle_train, worker_init_fn=worker_init_fn)
    test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False, worker_init_fn=worker_init_fn)

    if val_df is not None:
        val_dataset = CustomDataset(val_df)
        val_loader = DataLoader(val_dataset, batch_size=batch_size, shuffle=False, worker_init_fn=worker_init_fn)
        return train_loader, val_loader, test_loader

    return train_loader, test_loader
