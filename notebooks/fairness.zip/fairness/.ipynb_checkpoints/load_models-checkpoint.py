import torch

def restore_model(model_save_path, encoder, predictor, adversaries, optimizer_enc, optimizer_pred, optimizer_adversaries):
    """
    Restores the model and optimizer states from the saved checkpoint.
    
    Args:
    - model_save_path (str): Path to the saved model checkpoint file.
    - encoder (torch.nn.Module): The encoder model.
    - predictor (torch.nn.Module): The predictor model.
    - adversaries (list of torch.nn.Module): List of adversary models.
    - optimizer_enc (torch.optim.Optimizer): The optimizer for the encoder.
    - optimizer_pred (torch.optim.Optimizer): The optimizer for the predictor.
    - optimizer_adversaries (list of torch.optim.Optimizer): List of optimizers for the adversaries.
    
    Returns:
    - encoder, predictor, adversaries: The restored models.
    - optimizer_enc, optimizer_pred, optimizer_adversaries: The restored optimizers.
    """
    checkpoint = torch.load(model_save_path)
    
    encoder.load_state_dict(checkpoint['encoder_state_dict'])
    predictor.load_state_dict(checkpoint['predictor_state_dict'])
    
    for i, adversary in enumerate(adversaries):
        adversary.load_state_dict(checkpoint['adversaries_state_dict'][i])

    optimizer_enc.load_state_dict(checkpoint['optimizer_enc_state_dict'])
    optimizer_pred.load_state_dict(checkpoint['optimizer_pred_state_dict'])
    for i, optimizer in enumerate(optimizer_adversaries):
        optimizer.load_state_dict(checkpoint['optimizer_adversaries_state_dict'][i])

    print(f"Model restored from checkpoint at: {model_save_path}")

    return encoder, predictor, adversaries, optimizer_enc, optimizer_pred, optimizer_adversaries
